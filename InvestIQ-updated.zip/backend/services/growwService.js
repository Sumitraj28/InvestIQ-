/**
 * Groww API Service
 * Fetches real-time quarterly & yearly financial performance (Revenue & Profit),
 * fundamentals, and shareholding pattern for Indian equity stocks with offline baseline resilience.
 */

const cache = new Map();
const CACHE_TTL_MS = 60 * 60 * 1000; // 1 hour cache

function formatGrowth(current, previous) {
  if (!previous || previous === 0) return { percent: 0, isPositive: true, formatted: '+0.00%' };
  const diff = current - previous;
  const pct = (diff / Math.abs(previous)) * 100;
  const isPos = pct >= 0;
  return {
    percent: Number(pct.toFixed(2)),
    isPositive: isPos,
    formatted: `${isPos ? '+' : ''}${pct.toFixed(2)}%`,
  };
}

function buildFallbackFinancials(clean) {
  const years = ['2022', '2023', '2024', '2025'];
  const baseRev = clean === 'RELIANCE' ? 892000 : clean === 'TCS' ? 240893 : clean === 'INFY' ? 153670 : 85000;
  const baseProfit = Math.round(baseRev * 0.14);

  const yearlyList = years.map((y, idx) => {
    const factor = 1 + idx * 0.11;
    return {
      period: y,
      year: y,
      revenue: Math.round(baseRev * factor),
      profit: Math.round(baseProfit * factor),
    };
  });

  const quarters = ['Jun 24', 'Sep 24', 'Dec 24', 'Mar 25', 'Jun 25'];
  const qRev = Math.round(baseRev / 4);
  const qProf = Math.round(baseProfit / 4);

  const quarterlyList = quarters.map((q, idx) => {
    const factor = 1 + idx * 0.03;
    return {
      period: q,
      quarter: q,
      revenue: Math.round(qRev * factor),
      profit: Math.round(qProf * factor),
    };
  });

  const latestYear = yearlyList[yearlyList.length - 1];
  const prevYear = yearlyList[yearlyList.length - 2];
  const latestQuarter = quarterlyList[quarterlyList.length - 1];
  const prevQuarter = quarterlyList[quarterlyList.length - 2];

  return {
    source: 'offline-baseline',
    searchId: `offline-${clean}`,
    displayName: `${clean} Limited`,
    quarterly: quarterlyList,
    yearly: yearlyList,
    summary: {
      yearly: {
        latestPeriod: latestYear.period,
        revenue: latestYear.revenue,
        revenueGrowth: formatGrowth(latestYear.revenue, prevYear.revenue),
        profit: latestYear.profit,
        profitGrowth: formatGrowth(latestYear.profit, prevYear.profit),
      },
      quarterly: {
        latestPeriod: latestQuarter.period,
        revenue: latestQuarter.revenue,
        revenueGrowth: formatGrowth(latestQuarter.revenue, prevQuarter.revenue),
        profit: latestQuarter.profit,
        profitGrowth: formatGrowth(latestQuarter.profit, prevQuarter.profit),
      },
    },
    fundamentals: {
      'Market Cap': clean === 'RELIANCE' ? '₹19.50L Cr' : clean === 'TCS' ? '₹14.20L Cr' : '₹6.70L Cr',
      'P/E Ratio(TTM)': '26.80',
      'P/B Ratio': '2.45',
      'Industry P/E': '24.10',
      'Debt to Equity': '0.38',
      ROE: '13.50%',
      'EPS(TTM)': '₹85.40',
      'Dividend Yield': '0.35%',
      'Book Value': '₹1,240.00',
      'Face Value': '₹10.00',
    },
    shareholding: {
      period: 'Dec 2024',
      promoters: 50.30,
      fii: 22.40,
      dii: 16.50,
      public: 10.80,
    },
  };
}

async function fetchFromGroww(cleanSymbol) {
  // 1. Search entity on Groww
  const searchUrl = `https://groww.in/v1/api/search/v1/entity?app=false&entity_type=stocks&page=0&q=${encodeURIComponent(cleanSymbol)}&size=1`;
  const searchRes = await fetch(searchUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      Accept: 'application/json',
    },
  });

  if (!searchRes.ok) {
    throw new Error(`Groww search returned HTTP ${searchRes.status}`);
  }

  const searchData = await searchRes.json();
  const searchId = searchData?.content?.[0]?.search_id;
  if (!searchId) {
    throw new Error(`Groww searchId not found for ${cleanSymbol}`);
  }

  // 2. Fetch full company details by search_id
  const companyUrl = `https://groww.in/v1/api/stocks_data/v1/company/search_id/${searchId}`;
  const compRes = await fetch(companyUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      Accept: 'application/json',
    },
  });

  if (!compRes.ok) {
    throw new Error(`Groww company API returned HTTP ${compRes.status}`);
  }

  const compData = await compRes.json();
  const stmts = compData?.financialStatement || [];

  const revObj = stmts.find((s) => s.title?.toLowerCase().includes('revenue'));
  const profObj = stmts.find((s) => s.title?.toLowerCase().includes('profit'));
  const netWorthObj = stmts.find((s) => s.title?.toLowerCase().includes('net worth'));

  // Parse Yearly Data (last 3-5 years)
  const yearlyYears = Object.keys(revObj?.yearly || {}).sort();
  const yearlyList = yearlyYears.slice(-5).map((y) => {
    const rev = Number(revObj?.yearly?.[y] || 0);
    const prof = Number(profObj?.yearly?.[y] || 0);
    return {
      period: String(y),
      year: String(y),
      revenue: Math.round(rev),
      profit: Math.round(prof),
    };
  });

  // Parse Quarterly Data (last 5 quarters)
  const quarterlyQuarters = Object.keys(revObj?.quarterly || {});
  const quarterlyList = quarterlyQuarters.slice(-5).map((q) => {
    const rev = Number(revObj?.quarterly?.[q] || 0);
    const prof = Number(profObj?.quarterly?.[q] || 0);
    return {
      period: String(q),
      quarter: String(q),
      revenue: Math.round(rev),
      profit: Math.round(prof),
    };
  });

  // Calculate Summary metrics for Yearly
  const latestYear = yearlyList[yearlyList.length - 1];
  const prevYear = yearlyList.length > 1 ? yearlyList[yearlyList.length - 2] : null;
  const yearlyRevGrowth = formatGrowth(latestYear?.revenue || 0, prevYear?.revenue);
  const yearlyProfitGrowth = formatGrowth(latestYear?.profit || 0, prevYear?.profit);

  // Calculate Summary metrics for Quarterly
  const latestQuarter = quarterlyList[quarterlyList.length - 1];
  const prevQuarter = quarterlyList.length > 1 ? quarterlyList[quarterlyList.length - 2] : null;
  const quarterlyRevGrowth = formatGrowth(latestQuarter?.revenue || 0, prevQuarter?.revenue);
  const quarterlyProfitGrowth = formatGrowth(latestQuarter?.profit || 0, prevQuarter?.profit);

  // Parse Fundamentals
  const fundamentalsRaw = compData?.fundamentals || [];
  const fundamentalsMap = {};
  fundamentalsRaw.forEach((f) => {
    if (f.name && f.value) {
      fundamentalsMap[f.name] = f.value;
    }
  });

  // Parse Shareholding Pattern
  const shpRaw = compData?.shareHoldingPattern || {};
  const shpPeriods = Object.keys(shpRaw);
  let latestShp = null;
  if (shpPeriods.length > 0) {
    const latestPeriodKey = shpPeriods[0];
    const pData = shpRaw[latestPeriodKey];
    let promotersPct = 0;
    if (pData?.promoters) {
      const p = pData.promoters;
      promotersPct = (p.individual?.percent || 0) + (p.government?.percent || 0) + (p.corporation?.percent || 0);
    }
    const fiiPct = pData?.foreignInstitutions?.percent || 0;
    const diiPct = (pData?.mutualFunds?.percent || 0) + (pData?.otherDomesticInstitutions?.insurance?.percent || 0) + (pData?.otherDomesticInstitutions?.otherFirms?.percent || 0);
    const publicPct = pData?.retailAndOthers?.percent || 0;

    latestShp = {
      period: latestPeriodKey,
      promoters: Number(promotersPct.toFixed(2)),
      fii: Number(fiiPct.toFixed(2)),
      dii: Number(diiPct.toFixed(2)),
      public: Number(publicPct.toFixed(2)),
    };
  }

  return {
    source: 'groww',
    searchId,
    displayName: compData.header?.displayName,
    quarterly: quarterlyList,
    yearly: yearlyList,
    summary: {
      yearly: {
        latestPeriod: latestYear?.period || '',
        revenue: latestYear?.revenue || 0,
        revenueGrowth: yearlyRevGrowth,
        profit: latestYear?.profit || 0,
        profitGrowth: yearlyProfitGrowth,
      },
      quarterly: {
        latestPeriod: latestQuarter?.period || '',
        revenue: latestQuarter?.revenue || 0,
        revenueGrowth: quarterlyRevGrowth,
        profit: latestQuarter?.profit || 0,
        profitGrowth: quarterlyProfitGrowth,
      },
    },
    fundamentals: fundamentalsMap,
    shareholding: latestShp,
  };
}

/**
 * Main function: get real financials with in-memory caching and graceful baseline fallback
 */
async function getStockFinancials(ticker) {
  if (!ticker) throw new Error('Ticker is required');
  const clean = ticker.replace(/\.(NS|BO)$/i, '').trim().toUpperCase();

  const cached = cache.get(clean);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
    return cached.data;
  }

  try {
    const data = await fetchFromGroww(clean);
    cache.set(clean, { data, timestamp: Date.now() });
    return data;
  } catch (err) {
    console.warn(`[Groww API] Fetch failed for ${clean}: ${err.message}. Serving baseline financials.`);
    if (cached) return cached.data;
    const fallback = buildFallbackFinancials(clean);
    cache.set(clean, { data: fallback, timestamp: Date.now() });
    return fallback;
  }
}

module.exports = {
  getStockFinancials,
};
